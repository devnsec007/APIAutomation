package TEST;

import java.util.LinkedHashMap;
import java.util.Scanner;

import org.testng.annotations.Test;

import java.io.File;

import com.fasterxml.jackson.databind.ObjectMapper;



public class serializationandDserializationPractice {

	@Test
	public void SADprac() {
		
		LinkedHashMap<String, String> LHM = new LinkedHashMap<String, String>();
		
		String NodeName="";
		String NodeValue= "";
		
		Scanner SC1,SC2;
		SC1=new Scanner(System.in);
		SC2=new Scanner(System.in);
		
		
		for(int i=0;i<2;i++) {
		System.out.println("Enter Node Name:: ");	
		NodeName=SC1.nextLine();
		SC1.reset();
		System.out.println("Enter Node Value:: ");
		NodeValue= SC1.nextLine();
	
	
		LHM.put(NodeName, NodeValue);
			
		}
		
//		ObjectMapper OM =new ObjectMapper();
//		OM.writeValue(new File("GeneratedJSONFiles/JSON1.json"), LHM);
		SampleJSONclass SJC=new SampleJSONclass("NAME","VALUE");
		ObjectMapper objectMapper = new ObjectMapper();
		
		try{
		objectMapper.writeValue(new File("target/NEWJSON3.json"), LHM);
		} catch(Exception e) {
			e.printStackTrace();
			
		}
		
		
		
	}
	
	
	
}
