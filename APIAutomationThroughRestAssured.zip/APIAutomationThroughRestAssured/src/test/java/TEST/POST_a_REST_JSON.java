package TEST;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matcher.*;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.path.json.JsonPath;


public class POST_a_REST_JSON {

	@Test
	public void FunctionToPOSTJSON() {
	
		JSONObject request = new JSONObject();
		request.putIfAbsent("name", "Debasish");
		request.putIfAbsent("name", "Biswas");
		
		given().
			header("Content-Type","Application/json").
			body(request.toJSONString()).
			when().
			post("https://reqres.in/api/users").
			then().
			statusCode(201).
			log().
			all();
		
		
		
		
	}
	
	
	
}
