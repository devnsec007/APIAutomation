package TEST;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.json.simple.*;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;

import com.google.gson.Gson;

public class JSONParsingThroughSimpleJSON {

	public HashMap<String, String> Node_And_Value=new HashMap<String, String>();
	
	@Test	
	public void ParseJSON() throws Exception, ParseException {
		
		String propertiesFilePath="C:/Users/admin/git/repository/APIAutomationThroughRestAssured/src/test/resources/OtherFiles/PropertiesFile/customizedJSONConverter.properties";
		Properties Prop=propertiesReader(propertiesFilePath);
		String SourceJSONpath =  (String) Prop.get("SourceJSONpath");
	//	System.out.println(SourceJSONpath);
		
		FileReader Freader = new FileReader(SourceJSONpath);
		JSONParser Jparser = new JSONParser();
		JSONObject JOBJECT = (JSONObject) Jparser.parse(Freader);
		
		
		
		String JSON=JOBJECT.toString();
		
		HashMap<String,Object> MAP1= new Gson().fromJson(JSON, HashMap.class);
		
		
		System.out.println("This is the value of the child nodes");
	//	System.out.println(MAP1.get("page"));
		RecursiveMap(MAP1);
		
		Set<String> KEYSET  = Node_And_Value.keySet();
		for(String S: KEYSET) {
			
			System.out.println("NodeName:"+S+"  NodeValue:"+ Node_And_Value.get(S));
		}
				
		
	}
	
	public void RecursiveMap(HashMap<String, Object> MAP1) {
		
		
		String STR=null;
		
		Set<String> KEYSET  = MAP1.keySet();
		for(String S:KEYSET) {
			
			if(MAP1.get(S) instanceof Map<?, ?> ) {
						
				Gson GSON= new Gson();
				HashMap<String,Object> MAP2= new Gson().fromJson(GSON.toJsonTree(MAP1.get(S)), HashMap.class);
				RecursiveMap(MAP2);
			}
			
			else if(MAP1.get(S) instanceof Collection<?>){
				
				ArrayList<Object> SET2 =(ArrayList<Object>) MAP1.get(S); 
				for(Object OB:SET2) {
					
					Gson GSON= new Gson();
					HashMap<String,Object> MAP2= new Gson().fromJson(GSON.toJsonTree(OB), HashMap.class);
					RecursiveMap(MAP2);
					
					
				}
				
				
			}
			else {
				
				if(Node_And_Value.containsKey(S)) {
					
					//change this section of the code
					Node_And_Value.put(S+"-DUPE: ", MAP1.get(S).toString());
				}
				else
				{
					Node_And_Value.put(S, MAP1.get(S).toString());
				}
				
				
			}
				
			
		}
		
		
		
	}
	
	public Properties propertiesReader(String propertiesFilePath) {
		
		Properties Prop=new Properties();
		try {
			Prop = new Properties();
			FileInputStream FIM = new FileInputStream(propertiesFilePath);
			Prop.load(FIM);
			}
			catch(Exception e) {
				
			}
		
		return Prop;
		
		
	}
	
}
