package TEST;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.io.File;

import static io.restassured.RestAssured.*;


public class SOAPrequestPosting {
	
	@Test
	public void SOAPRequestPosting() {
		
		String FilePath="C:/Users/admin/Downloads/BDD_Hybrid_Project1-master/APIAutomationThroughRestAssured/src/test/resources/SampleXML/calculator.xml";
				
		try {
			String XMLBODY = IOUtils.toString(new FileInputStream(new File(FilePath))) ;
			POSTINGXML(XMLBODY);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void POSTINGXML(String XML) {
		
		
		Response RS=given().
		contentType("text/xml").
		body(XML).
		when().
		post("https://www.dataaccess.com/webservicesserver/NumberConversion.wso");
		
		System.out.println(RS.asPrettyString());
		
		
	}
}
