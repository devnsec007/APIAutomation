package TEST;

public class SampleJSONclass {
	String NodeName;
    String NodeValue;
    
    
	public SampleJSONclass(String Name,String Value) {
    	
    	NodeName=Name;
    	NodeValue=Value;
    	
		 
    }
}
