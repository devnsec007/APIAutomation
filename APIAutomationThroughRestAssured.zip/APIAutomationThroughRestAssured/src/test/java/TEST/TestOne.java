package TEST;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class TestOne {

	@Test
	public void Test1() {
		
		Response RS= RestAssured.get("https://reqres.in/api/users?page=2"); 
		System.out.println(RS.getBody().asPrettyString());
		System.out.println("-----------------------");
		System.out.println(RS.getStatusCode());
		Assert.assertEquals(200, RS.getStatusCode());
		System.out.println("-----------------------");
		System.out.println(RS.getHeaders().toString());
		
	}
	
}
