package Utilities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.File;
import java.io.IOException;

import org.testng.annotations.Test;

public class XMLNodeValueDisplayer {

	@Test
	public static void NodeValuedisplayer() {
		

	/*	System.out.println("Enter the path of the XML/JSON file , that Needs to be validated:: \n");
		Scanner sc = new Scanner(System.in);
		String FILEPATH=sc.nextLine();*/

		String FILEPATH="C:/Users/admin/Desktop/SampleXML2.xml";

		if(FILEPATH.contains(".xml")) {

			boolean XMLPATH=FILEPATH.contains(".xml");
			if(XMLPATH) {
				XMLValidator_BY_DB(FILEPATH);
			}
				

			}
			else
				
			{
				System.out.println("Invalid File Extension");
				System.exit(0);
			}

		}

	private static void XMLValidator_BY_DB(String fILEPATH) {
		
		String NodeValue;

		ArrayList<String> Duplicate_Node = new ArrayList<String>();
		
		String duplicateNodeName="";
		
		try {
			DocumentBuilder DBFAC = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document DOC=DBFAC.parse(new File(fILEPATH));
			NodeList NODELIST1=DOC.getElementsByTagName("*");
			
			for(int i=0;i<NODELIST1.getLength();i++) {

				Element node=(Element) NODELIST1.item(i);
				
				NodeList CH1= node.getChildNodes();
				
				
				int frequency;
				if(CH1.getLength()==1) {
					if(Duplicate_Node.contains(node.getNodeName())) {
						frequency=Collections.frequency(Duplicate_Node, node.getNodeName())+1;
						System.out.println(node.getNodeName()+"[" +Integer.toString(frequency)+"]" + " ::  " + node.getTextContent());
					}
					else
					{System.out.println(node.getNodeName()+ " ::  " + node.getTextContent());}
					
					Duplicate_Node.add(node.getNodeName().toString());
				}}
			
			
		}	
			catch (Exception e) {
			
				e.printStackTrace();
			}}}
	
	

