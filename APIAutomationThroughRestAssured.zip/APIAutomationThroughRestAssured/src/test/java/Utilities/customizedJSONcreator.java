package Utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.io.File;

import org.json.JSONObject;
import org.testng.annotations.Test;






public class customizedJSONcreator {

	
	
	/*
	
	public void CustomJSONCreater() {
		
		String propertiesFilePath="C:/Users/admin/git/repository/APIAutomationThroughRestAssured/src/test/resources/OtherFiles/PropertiesFile/customizedJSONConverter.properties";
		Properties propertiesFile =propertiesReader(propertiesFilePath) ;
		
		String SourceJSONpath =  (String) propertiesFile.get("SourceJSONpath");
		String MasterDSPath =(String) propertiesFile.get("MasterDSPath");
		
		Gson gson =new Gson();
		try {
		String JSON= new String(Files.readAllBytes(Paths.get(SourceJSONpath)));
		LinkedHashMap<String , String> JOBJ=gson.fromJson(JSON, LinkedHashMap.class);
		XmlMapper xmlMapper = new XmlMapper();
		String xml = xmlMapper.writeValueAsString(JOBJ);
		
		System.out.println(xml);
		
		
		
		}
		catch(Exception e) {
			
		}
	}
	*/
	public Properties propertiesReader(String propertiesFilePath) {
	
		Properties Prop=new Properties();
		try {
			Prop = new Properties();
			FileInputStream FIM = new FileInputStream(propertiesFilePath);
			Prop.load(FIM);
			}
			catch(Exception e) {
				
			}
		
		return Prop;
		
		
	}
	
	@Test
	public void JSONlearn() {
		String propertiesFilePath="C:/Users/admin/git/repository/APIAutomationThroughRestAssured/src/test/resources/OtherFiles/PropertiesFile/customizedJSONConverter.properties";
		Properties Prop=propertiesReader(propertiesFilePath);
		String SourceJSONpath =  (String) Prop.get("SourceJSONpath");
		String JSONString;
		try {
			JSONString = new String(Files.readAllBytes(Paths.get(SourceJSONpath)));
			System.out.println(JSONString);
			JSONObject JSON1 = new JSONObject();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
	//	JSONObject JSON1 = new JSONObject(JSONString);
		
		
	}
	
	
	
}
