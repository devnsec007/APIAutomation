package Utilities;

import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


import org.testng.annotations.Test;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;



import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;



public class CombinedJSONXMLSearch {
	
	@Test
	public void JSONVALIDATOR1() {


		System.out.println("Enter the path of the XML/JSON file , that Needs to be validated:: \n");
		Scanner sc = new Scanner(System.in);
		String FILEPATH=sc.nextLine();


		if(FILEPATH.contains(".json")|FILEPATH.contains(".xml")) {

			boolean JSONORXML=FILEPATH.contains(".json");
			if(JSONORXML) {
				ThroughGSONValidator(FILEPATH);
			}
				else
				{
					ThroughXMLDOMValidator(FILEPATH);
				}

			}
			else
				
			{
				System.out.println("Invalid File Extension");
				System.exit(0);
			}

		}


		public String readFileAsString(String fileName)throws Exception
		{
			String data = "";
			data = new String(Files.readAllBytes(Paths.get(fileName)));
			return data;
		}



		private void ThroughGSONValidator(String FilePath) {
		String JSONContentString=null;
		try {
			JSONContentString=readFileAsString(FilePath);
		} catch (Exception e1) {

			e1.printStackTrace();
		}

		Gson gson =new Gson();

		
		try {
			@SuppressWarnings("unchecked")




				LinkedHashMap<String , String> JOBJ=gson.fromJson(JSONContentString, LinkedHashMap.class);
				System.out.println(Arrays.asList(JOBJ));
				XmlMapper xmlMapper = new XmlMapper();
				String xml = xmlMapper.writeValueAsString(JOBJ);

				XMLVALIDATOR(xml);



			}
			catch (IllegalStateException e)
			{
				}

		catch (Exception e) {

			e.printStackTrace();
}


		}


		private void ThroughXMLDOMValidator(String FilePAth) {

			String XMLContentString=null;
			try {
			XMLContentString=readFileAsString(FilePAth);
				} catch (Exception e1) {

						e1.printStackTrace();
				}

			XMLVALIDATOR(XMLContentString);
		}

		private void XMLVALIDATOR(String xml) {

				try {
						DocumentBuilder DB = DocumentBuilderFactory.newInstance().newDocumentBuilder();
						Document docXML = DB.parse(new InputSource(new StringReader(xml)));

						NodeList nodelist =docXML.getElementsByTagName("*");

						System.out.println("Enter Searching Node::");
						Scanner sc = new Scanner(System.in);

						VlidateXML(sc.nextLine(),nodelist);

				}

		catch (IllegalStateException e)
				{
					}

		catch (Exception e) {

			e.printStackTrace();
			}
			}


			private void VlidateXML(String nextLine, NodeList nodelist) {

				String id="";
				for(int i=0;i<nodelist.getLength();i++) {

					Element node=(Element) nodelist.item(i);
					if(node.getNodeType()==Node.ELEMENT_NODE) {
						String TagName =node.getNodeName().toString();


						if(nextLine.equalsIgnoreCase(TagName)) {
							String TagValue =node.getTextContent().toString();
							System.out.println(TagValue);
}

					}


}

}

}