package TEST;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

public class HandlingDynamicWebtable {
	
	@Test
	public void HandlingDynamicWebtable() {
		
		System.setProperty("webdriver.chrome.driver",
			    "C:/Users/admin/Downloads/BDD_Hybrid_Project1-master/KarateFWPractice/src/test/resources/Driver/chromedriver.exe");
				
				ChromeOptions CO = new ChromeOptions();
				//This is the recent hack for ChromeDriver issue with the latest Selenium
				CO.addArguments("--remote-allow-origins*");
				WebDriver driver = new ChromeDriver(CO);
			  	
			  	driver.manage().window().maximize();
			  	driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
			  	driver.get("https://www.techlistic.com/p/demo-selenium-practice.html");
			  	
			  	JavascriptExecutor JS = (JavascriptExecutor)driver;
			  	JS.executeScript("document.querySelector(window.scrollTo(0,800))");
			  	
			  	
			  	WebElement Table1 = driver.findElement(By.xpath("//table[@class='tsc_table_s13']"));
			  	List<WebElement>  TR = Table1.findElements(By.tagName("tr"));
			  	
			  	List<WebElement> TH = TR.get(0).findElements(By.tagName("th"));
			  	
			  	int counter=0;
			  	for(WebElement Header:TH ) {
			  		counter++;
			  		if(Header.getText().equalsIgnoreCase("Height"))
			  			break;
			  	}
			  
			  	
			  	ArrayList<String> HightValues = new ArrayList<String>();
					
			  
			  	for(int i=2;i<(TR.size());i++) {
			  		
			  		List<WebElement> TD =TR.get(i).findElements(By.tagName("td"));
			  		//System.out.println(TD.size());
			  		//System.out.println(TD.get(counter-2).getText());
			  		HightValues.add(TD.get(counter-2).getText());    
			  			
			  		}
				System.out.println("Hight of the building are ::");		
			  	for(String Values:HightValues) {
			  		
			  		System.out.println(Values.toString());
			  	}
			  	
			  	}
		
		
	}
	
	
	

