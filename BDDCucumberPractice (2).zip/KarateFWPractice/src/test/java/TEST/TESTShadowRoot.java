package TEST;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import org.openqa.selenium.interactions.Actions;

public class TESTShadowRoot {

	
	
@Test	
public void Setup() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver",
			    "C:/Users/admin/Downloads/BDD_Hybrid_Project1-master/KarateFWPractice/src/test/resources/Driver/chromedriver.exe");
				
				ChromeOptions CO = new ChromeOptions();
				//This is the recent hack for ChromeDriver issue with the latest Selenium
				CO.addArguments("--remote-allow-origins*");
				WebDriver driver = new ChromeDriver(CO);
			  	
			  	driver.manage().window().maximize();
			  	driver.manage().timeouts().implicitlyWait(1,TimeUnit.SECONDS);
			  	driver.get("https://www.google.com/");
			  	Thread.sleep(200);
			  	driver.switchTo().frame("callout");
			  	driver.findElement(By.xpath("//button[@class='M6CB1c rr4y5c']")).click();
			  	driver.switchTo().defaultContent();
			  	
			  	JavascriptExecutor JS = (JavascriptExecutor)driver;
			  	Thread.sleep(200);
			  	
			  	WebElement SearchBar = (WebElement)JS.executeScript(" return document.querySelector('body > div.L3eUgb > div.o3j99.ikrT4e.om7nvf > form > div:nth-child(1) > div.A8SBwf> div.RNNXgb > div > div.a4bIc > input')");
			  	Thread.sleep(200);
			 	SearchBar.sendKeys("WebServices");
			 	Actions act = new Actions(driver);
			 	act.sendKeys(Keys.ENTER).build().perform();
			 	
			 	
			 	
			  
	}
	
	
}
