import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import io.cucumber.java.After;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Stepdef1 {

	
	

@Given("I want to write a step with precondition")
public void i_want_to_write_a_step_with_precondition() {

	System.out.println("Precondition Step");
	
	
}

@Given("some other precondition")
public void some_other_precondition() {
	System.out.println("Other Precondition Step");
}

@When("I complete action")
public void i_complete_action() {

	System.out.println("Complete Action");
	
}

@Then("I validate the outcomes")
public void i_validate_the_outcomes() {

	System.out.println("Validate Outcome");
}

@Given("I want to write a step with name1")
public void i_want_to_write_a_step_with_name1() {

	System.out.println("Step Name 1");
}

@When("I check for the {int} in step")
public void i_check_for_the_in_step(Integer int1) {

	System.out.println("Step Step");
	
}

@Then("I verify the success in step")
public void i_verify_the_success_in_step() {

	System.out.println("Success in Step");
	
}

@Given("I want to write a step with name2")
public void i_want_to_write_a_step_with_name2() {

	System.out.println("Step Name 2");
	
}

@Then("I verify the Fail in step")
public void i_verify_the_fail_in_step() {

	System.out.println("Fall in Step");
}

	
}
